package com.example.studentmanagment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;

public class MyDatabase extends SQLiteOpenHelper {

    private static String dbname = "my_database";
    private static int dbversion = 1;
    Context context;

    MyDatabase(Context ct) {
        super(ct, dbname, null, dbversion);
        this.context = ct;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Toast.makeText(context, "OnCreate MyDataBase", Toast.LENGTH_SHORT).show();
        String str = "create table info (id text,number text,name text,section text)";
        sqLiteDatabase.execSQL(str);
    }

    public void insertValues(String s1, String s2, String s3,String s4) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", s1);
        contentValues.put("number", s2);
        contentValues.put("name", s3);
        contentValues.put("section", s4);
        db.insert("info", null, contentValues);
        Toast.makeText(context, "Insert Completed ", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public ArrayList<String> showValues() {
        Toast.makeText(context, "Inside show values", Toast.LENGTH_SHORT).show();
        SQLiteDatabase db = getReadableDatabase();
        String s = "Select * from info";
        Cursor cursor = db.rawQuery(s, null);

        ArrayList<String> arrayList = new ArrayList<>();

        while (cursor.moveToNext()) {
            String s1 = cursor.getString(0);
            String s2 = cursor.getString(1);
            String s3 = cursor.getString(2);
            String s4 = cursor.getString(3);

            String s5 = "Id is: " + s1 + "\nMobile No. is: " + s2 + "\nName is :" + s3 + "\nSection is :" + s4;
            arrayList.add(s5);
        }
        return arrayList;
    }

    public void doDelete(String str) {
        SQLiteDatabase db = getWritableDatabase();
        String where = "id = ?";
        String ss[] = {str};
        db.delete("info", where, ss);
        Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show();
    }

    public void doUpdate(String s1,String s2,String s3,String s4) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("number", s2);
        contentValues.put("name", s3);
        contentValues.put("section", s4);
        String where = "id = ?";
        String ss[] = {s1};
        db.update("info", contentValues, where, ss);
        Toast.makeText(context, "Updated", Toast.LENGTH_SHORT).show();
    }

    public ArrayList<String> doSearch(String s1) {
        SQLiteDatabase db = getReadableDatabase();

        String s = "Select * from info where id = ?";
        String ss[] = {s1};
        Cursor cursor = db.rawQuery(s,ss);
        ArrayList<String> arrayList = new ArrayList<>();

        while (cursor.moveToNext()) {
            String s2 = cursor.getString(0);
            String s3 = cursor.getString(1);
            String s4 = cursor.getString(2);
            String s5 = cursor.getString(3);
            String s6 = "Id is: " + s2 + "\nMobile No. is: " + s3 + "\nName is :" + s4 + "\nSection is :" + s5;
            arrayList.add(s6);
        }
        return arrayList;

    }
}
