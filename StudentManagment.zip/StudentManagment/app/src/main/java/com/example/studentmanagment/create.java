package com.example.studentmanagment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class create extends AppCompatActivity {

    EditText id,number,name,section;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        id = findViewById(R.id.id);
        number = findViewById(R.id.number);
        name = findViewById(R.id.name);
        section = findViewById(R.id.section);
    }

    public void createEntery(View view) {
        MyDatabase db = new MyDatabase(getApplicationContext());
        db.insertValues(id.getText().toString(), number.getText().toString(), name.getText().toString(),section.getText().toString());
        finish();
        startActivity(new Intent(getApplicationContext(),MainActivity.class));

    }
}
