package com.example.studentmanagment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class search extends AppCompatActivity {

    EditText searchid;
    ArrayList<String> arrayList;
    ListView listviews;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        searchid = findViewById(R.id.searchid);
        listviews = findViewById(R.id.listviews);
    }

    public void searchRecord(View view) {
        MyDatabase db = new MyDatabase(getApplicationContext());
        arrayList = db.doSearch(searchid.getText().toString());
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList);
        listviews.setAdapter(arrayAdapter);

    }
}
