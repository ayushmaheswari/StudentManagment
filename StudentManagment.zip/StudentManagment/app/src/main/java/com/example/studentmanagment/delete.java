package com.example.studentmanagment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class delete extends AppCompatActivity {

    EditText delid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        delid = findViewById(R.id.delid);
    }

    public void delRecord(View view) {
        MyDatabase db = new MyDatabase(getApplicationContext());
        db.doDelete(delid.getText().toString());
        startActivity(new Intent(getApplicationContext(),MainActivity.class));
    }

}
